# UPSET Experimental v1 — independent review package

Start with [Why Gaethje went from 84 to 83](case/GAETHJE_WALKTHROUGH.md).
It explains the calculation, the model choice worth questioning, and what
to review next. The sample is drawn from UPSET's recorded data.

| File | What it contains |
| --- | --- |
| `case/gaethje-topuria.json` | Full precision before/after rows for both fighters, score history, and the recorded fight inputs |
| `methods/OVERALL_RATING_PROTOCOL_V1.md` | Declared feature, selection, date, and display rules |
| `methods/VALIDATION_REPORT.md` | Historical development results, limitations, and preservation audit |
| `evidence/model.json`, `config.json` | Fitted blend and slopes, full fixed reference curve, and settings |
| `evidence/evaluation.json` | Detailed comparison, subgroup results, and the displayed-rating track record |
| `evidence/development.jsonl` | All 3,149 matched scored fights with pre-fight component indices |
| `evidence/displayed_comparisons.jsonl` | Every decisive fight considered for the displayed-grade record, including ties and unavailable grades |
| `evidence/*summary.json`, `snapshot-provenance.json` | Audit summaries and original file fingerprints |
| `source/`, `tests/` | Original model/serving sources and project tests for inspection |
| `figures/` | Model comparison and a clean screenshot of the Gaethje panel |

After extracting the ZIP, run `python3 verify_review.py` from this folder to
check the worked example, saved development log loss, displayed-grade track
record, and bundle hashes. It requires only Python's standard library.

The source and project tests are reference copies, not a standalone UPSET
installation. A complete replay from raw bouts requires the original reviewed
database and the rest of the repository. This package contains selected fight
inputs and evaluation records, not the full database, credentials, roster
assets, or private browser screenshot. It does not change or retrain the model.

This is an experimental performance index. Historical development results do
not establish its performance on fresh fights or determine an individual
fighter's win probability.
