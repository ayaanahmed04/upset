# UPSET rating review

Start with [What changed in Experimental v2](REVIEW_ADDENDUM.md). It walks
through the Gaethje case, shows how often the display moved against a result,
and compares the two versions on the same historical fights.

| File | Contents |
| --- | --- |
| `case/gaethje-topuria.json` | Recorded fight totals and exact rating inputs before and after the fight |
| `evidence/validation-v2.json` | The declared gates, measured comparison, saved prefix check and subgroups |
| `evidence/v1-audit.json`, `evidence/v2-audit.json` | Cohorts, outcome counts, movement limits and named 99 states |
| `evidence/development.jsonl` | Named matched fights, stored pre-fight component inputs and per-fight loss for both models |
| `evidence/displayed-comparisons.jsonl` | Named decisive fights and the strictly earlier grades used in each comparison |
| `evidence/rating-updates-v*.jsonl` | Named fighter-date states used to verify the display history |
| `evidence/model-v*.json` | Skill and résumé blend, evaluation slope and fixed grading curve |
| `evidence/snapshot-provenance.json` | Hashes for the frozen inputs, outputs and original manifests |
| `methods/`, `source/` | Declared protocols and model source reference copies |

Extract the whole archive and run `python3 verify_review.py` from this folder.
It uses Python 3.10 or newer and its standard library. The source reference
copies need the rest of UPSET and the original reviewed database for full
feature replay. The bundle covers previously inspected historical development
fights. Performance on new fights requires separate evaluation.
