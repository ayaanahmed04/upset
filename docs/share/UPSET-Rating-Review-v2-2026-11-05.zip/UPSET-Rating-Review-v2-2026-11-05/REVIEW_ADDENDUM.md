# What changed in Experimental v2

The archived run met the local experimental preview gates. These are development results on previously inspected recorded fights.

## Justin Gaethje and Ilia Topuria

UPSET records Gaethje winning a June 14, 2026 title bout by KO/TKO at 5:00 of round
four. The stored record leaves the circumstances of the stoppage unspecified.
Topuria landed 97 of 162 significant strikes and scored the only recorded
knockdown. Gaethje landed 91 of 192 and went 0 for 5 on takedowns.

| Calculation | Experimental v1 | Experimental v2 |
| --- | ---: | ---: |
| Striking | 85.715 → 84.939 | 86.395 → 86.711 |
| Wrestling | 81.402 → 80.064 | 81.402 → 80.064 |
| Grappling | 80.273 → 80.117 | 80.273 → 80.117 |
| Résumé | 88.524 → 89.616 | 88.524 → 89.616 |
| Combined before grading | 84.630 → 84.292 | 86.098 → 86.510 |
| Displayed badge | 84 → 83 | 88 → 89 |

In v1, Résumé contributed +0.273 combined points, Striking contributed −0.291,
and Wrestling plus Grappling contributed −0.320. The two lower skills traded
places in the ranked blend, so the audit groups them. The combined decrease of
0.338 crossed a rounding boundary. V1 counted KO/TKO losses in Striking and used
an opponent's KO/TKO wins as a defense comparison. V2 adds direct credit for the
fighter's own KO/TKO wins alongside the existing KO/TKO loss feature.

V2 gives Résumé half the combined weight. The skills blend stays at 50% strongest,
30% second and 20% third. The fixed curve uses pre-2019 fighter-date states.
The outcome hold comes after grading and caps. Gaethje's v2 post-fight badge
before that last rule was **89**. The saved hold reason
for this update is **none**.

## How often badges moved against the result

The earlier ZIP sample compares two consecutive decisive appearances within its
2019 to October 25, 2026 comparison window. It requires a rated state from each
appearance and checks that the later pre-fight grade dates to the earlier bout.
The full history follows each fighter's consecutive states through October 31,
including the final update when there is no later bout. The three columns below
use those scopes. The 90+ condition uses the pre-update badge.

| Measure | v1 earlier sample | v1 full history | v2 full history |
| --- | ---: | ---: | ---: |
| Wins that lowered the badge | 322 / 3,131 (10.3%) | 363 / 3,506 (10.4%) | 0 / 3,506 (0.0%) |
| Wins at 90+ that lowered the badge | 43 / 231 (18.6%) | 53 / 263 (20.2%) | 0 / 308 (0.0%) |
| Losses that raised the badge | 143 / 2,428 (5.9%) | 214 / 3,425 (6.2%) | 0 / 3,425 (0.0%) |
| Displayed move of exactly five | 1,119 / 5,559 (20.1%) | 1,405 / 6,931 (20.3%) | 1,325 / 6,931 (19.1%) |
| Five-point limit applied | 690 / 5,559 (12.4%) | 859 / 6,931 (12.4%) | 734 / 6,931 (10.6%) |
| Exactly five with 10+ prior bouts | 186 / 1,724 (10.8%) | 240 / 2,175 (11.0%) | 224 / 2,175 (10.3%) |
| Limit applied with 10+ prior bouts | 79 / 1,724 (4.6%) | 100 / 2,175 (4.6%) | 94 / 2,175 (4.3%) |

The limit applied when the pre-hold movement would have exceeded five points.
An exact five-point change can occur on its own. V2 held 116
winner updates and 50 loser updates through October 31.
The fixed curve is steepest between 89 and 94. Those five grade points span
the 95th through 97th percentiles. V2 keeps that section and the movement limit.

## The top grade

V1 half-up rounding made an unrounded 98.5 display as 99. That threshold begins
at the top 0.255% of the fixed historical reference curve. V2 requires a curve
grade of 99 at or above the 99.99th reference percentile. A win hold can retain
a previous 99. The reference compares fighter-date states, including multiple
states for the same fighter.

| Version | Fighters who displayed 99 | 99 states earned / held |
| --- | --- | ---: |
| v1 | Amanda Nunes, Anthony Hernandez, Islam Makhachev, Jailton Almeida, Kamaru Usman, Khabib Nurmagomedov, Khamzat Chimaev, Merab Dvalishvili, Tatiana Suarez | 20 / 0 |
| v2 | Khabib Nurmagomedov | 1 / 0 |

## Matched historical comparison

Across 3,149 identical fights, log loss was
**0.66375** for v1 and **0.66533**
for v2. Lower is better. The archived 95% paired date-bootstrap interval for
the change was -0.00056 to
+0.00364. On the 2,828
fights where both versions gave the fighters unequal grades, the higher grade
was on the winner **1,705 times in v1** and
**1,706 times in v2**. An individual badge is a 60–99 index.

The verifier recomputes the matched arithmetic, grade comparisons and display
rules from the saved evidence. A full replay of the opponent features requires
the original reviewed bout database. The archived date-block bootstrap and
prefix checks are described in the [v2 protocol](methods/v2.md).
